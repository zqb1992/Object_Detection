A basic demo in MATLAB.

Detection is also implemented in MATLAB (though missing some bells and whistles
compared to the Python version) via the fast_rcnn_im_detect() function.

See fast_rcnn_demo.m for example usage.
