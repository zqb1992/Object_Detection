% Set your own experiments directory
EXP_DIR = './cachedir/foo/bar';

% Do not use the GPU
USE_GPU = false;
